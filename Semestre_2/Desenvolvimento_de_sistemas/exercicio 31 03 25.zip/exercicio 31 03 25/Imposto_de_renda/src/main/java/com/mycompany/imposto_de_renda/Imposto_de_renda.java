/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.imposto_de_renda;

import javax.swing.JOptionPane;

/**
 *
 * @author Aluno CA
 */
public class Imposto_de_renda {

    public static void main(String[] args) {
        String Salario = JOptionPane.showInputDialog("Informe o seu sálario");
        
        float salariobruto = Float.parseFloat(Salario);
        
        double salarioliquido = 0;
        double desconto = 0;
        
        if(salariobruto <= 2259.20 ){
            JOptionPane.showMessageDialog(null,"Insento");
        } else if (salariobruto >= 2259.21 && salariobruto <= 2826.65){
            desconto = salariobruto * 0.075;
            salarioliquido = salariobruto - desconto;
            String MensagemA = "Seu salario bruto é R$ "+ salariobruto +" \n seu desconto é 7,5% de R$ "+ desconto+" \n e e o seu sálario com desconto é R$ "+ salarioliquido;
            JOptionPane.showMessageDialog(null, MensagemA);
        } else if (salariobruto >= 2826.66 && salariobruto <= 3751.05){
            desconto = salariobruto * 0.15;
            salarioliquido = salariobruto - desconto;
            String MensagemB = "Seu salario bruto é R$ "+ salariobruto +" \n seu desconto é de 15% R$ "+ desconto+" \n e e o seu sálario com desconto é R$ "+ salarioliquido;
            JOptionPane.showMessageDialog(null, MensagemB);
    } else if (salariobruto >= 3751.06 && salariobruto <= 4664.68){
            desconto = salariobruto * 0.225;
            salarioliquido = salariobruto - desconto;
            String MensagemC = "Seu salario bruto é R$ "+ salariobruto +" \n seu desconto é de 22,5% R$ "+ desconto+" \n e e o seu sálario com desconto é R$ "+ salarioliquido;
            JOptionPane.showMessageDialog(null, MensagemC);
} else if ( salariobruto > 4664.68){
        desconto = salariobruto * 0.275;
            salarioliquido = salariobruto - desconto;
            String MensagemC = "Seu salario bruto é R$ "+ salariobruto +" \n seu desconto é de 27,5% R$ "+ desconto+" \n e e o seu sálario com desconto é R$ "+ salarioliquido;
            JOptionPane.showMessageDialog(null, MensagemC);
    }
}
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.inss_exercicio;

import javax.swing.JOptionPane;

/**
 *
 * @author Aluno CA
 */
public class INSS_exercicio {

    public static void main(String[] args) {
        String Salario = JOptionPane.showInputDialog("Informe o seu sálario");
        
        float salariobruto = Float.parseFloat(Salario);
        
        double salarioliquido = 0;
        double desconto = 0;
        
        if(salariobruto <= 1518){
            desconto = salariobruto * 0.075;
            salarioliquido = salariobruto - desconto;
            String MensagemA = "Seu salario bruto é R$ "+ salariobruto +" \n seu desconto é 7,5% de R$ "+ desconto+" \n e e o seu sálario liquido é R$ "+ salarioliquido;
            JOptionPane.showMessageDialog(null, MensagemA);
        } else if (salariobruto >= 1518.01 && salariobruto <= 2793.88){
            desconto = salariobruto * 0.09;
            salarioliquido = salariobruto - desconto;
            String MensagemA = "Seu salario bruto é R$ "+ salariobruto +" \n seu desconto é 9% de R$ "+ desconto+" \n e e o seu sálario liquido é R$ "+ salarioliquido;
            JOptionPane.showMessageDialog(null, MensagemA);
        } else if(salariobruto >= 2793.89 && salariobruto <= 4190.83){
        desconto = salariobruto * 0.12;
            salarioliquido = salariobruto - desconto;
            String MensagemA = "Seu salario bruto é R$ "+ salariobruto +" \n seu desconto é 12% de R$ "+ desconto+" \n e e o seu sálario liquido é R$ "+ salarioliquido;
            JOptionPane.showMessageDialog(null, MensagemA);
    } else if(salariobruto > 4190.84){
        desconto = salariobruto * 0.14;
            salarioliquido = salariobruto - desconto;
            String MensagemA = "Seu salario bruto é R$ "+ salariobruto +" \n seu desconto é 14% de R$ "+ desconto+" \n e e o seu sálario liquido é R$ "+ salarioliquido;
            JOptionPane.showMessageDialog(null, MensagemA);
    }
    }
}
